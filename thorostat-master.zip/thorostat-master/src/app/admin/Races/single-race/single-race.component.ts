import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'single-race',
  templateUrl: './single-race.component.html',
  styleUrls: ['./single-race.component.scss']
})
export class SingleRaceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
