import { Component } from '@angular/core';

@Component({
  selector: 'ngx-logs',
  templateUrl: './logs.component.html',
})
export class LogsComponent {

  // toggle details info
  toggleDetails(event: any, toggleClass: string) {
  }
}
