import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-log',
  templateUrl: './log.component.html',
  styleUrls: ['./log.component.scss'],
})
export class LogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
