export class TrackColor {
  id: number;
  track_number: string;
  towel_color: string;
  number_color: string;
}
