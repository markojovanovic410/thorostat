export class TrackCode {
  id: number;
  track_code: string;
  track_name: string;
  track_location: string;
}
