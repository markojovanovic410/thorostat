export class User {
  id: number;
  first_name: string;
  last_name: string;
  user_name: string;
  email: string;
  user_type: string;
  token: string;
}
